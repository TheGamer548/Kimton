import craft
import os
import __main__
os.system("py -m pip install pygame")
import pygame

